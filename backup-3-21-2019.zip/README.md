# multi-tenant
Multi Tenancy for single installation of Laravel App
