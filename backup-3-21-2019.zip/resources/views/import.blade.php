<!DOCTYPE html>
<html>
<head>
	<!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/jquery-ui.css') }}">
	<title>Drag and drop your file</title>
	<style>
		.drag_area {
			width: 600px;
			height: 600px;
			border: 2px dashed #ccc;
			color: #ccc;
			line-height: 600px;
			font-size: 32px;
			text-align: center;
			margin: 50px auto;
		}
		.drag_area:hover {
			cursor: pointer;
		}
		.drag_over {
			color: #000;
			border-color: #000;
		}
		.uploaded_file {
			margin: 0px auto;
		}

		/**/
		.dropable {
			border: 1px solid #222;
			width: 100%;
			min-height: 50px;
			padding: 0px;
		}
		.draggable {
			cursor: move;
			border: 1px solid #ddd;
			background-color: #ddd;
			padding: 10px 15px;
		}

		.data_fields .draggable {
			margin-top: 15px;
			margin-bottom: 15px;
		}
	</style>
</head>
<body>
	
	<div class="container">
		<div class="drag_area">
			Drop File here or click here
		</div>
		<form id="upload_form">
			@csrf
			<input type="file" name="files[]" id="upload" style="display:none"/
			multiple>
		</form>
		<div class="row assign_data_filed">
			<div class="col-md-6 assign_data_filed_left"></div>
			<div class="col-md-6 assign_data_filed_right"></div>
		</div>
		<div class="uploaded_file table-responsive"></div>
	</div>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="{{ asset('assets/js/jquery-ui.min.js') }}"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o" crossorigin="anonymous"></script>
	<script>
	    $(document).ready(function(){
	        $.ajaxSetup({
	            headers: {
	                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
	            }
	        });
	    });
	</script>
	<script>
		$(document).ready(function(){
			$('.drag_area').on("dragover", function(){
				$(this).addClass("drag_over");
				return false;
			}).on("dragleave", function(){
				$(this).removeClass("drag_over");
				return false;
			}).on("drop", function(e){
				e.preventDefault();
				$(this).removeClass("drag_over");
				var formData = new FormData();
				var input_files = e.originalEvent.dataTransfer.files;

				for(var i=0; i < input_files.length; i++ ) {
					formData.append('files[]', input_files[i]);
				}
				
				uploadFile(formData);
				
			}).on("click", function(e){
				$('#upload').trigger('click');
			});

			$('#upload').on("change", function(){
				var formData = new FormData($('#upload_form')[0]);
				uploadFile(formData);
			});
		});

		function uploadFile(formData , action = '/importData') {
			$.ajax({
				url : action,
				method : 'POST',
				dataType : 'json',
				data : formData,
				contentType : false,
				cache : false,
				processData : false,
				success : function( result ) {
					if(result.success == true) {
						console.log( result );
						// For Data fields
						var droppableContainer = $('<div class="row mb-3 dropable-container"></div>');
						$.each(result.labels, function(index, label){
							$('<div class="col-md-6" data-label="'+label+'">'+label+'</div>').appendTo(droppableContainer);
							$('<div class="col-md-6 dropable"></div>').droppable({
					        	accept: ".draggable",
					        	classes: {
					        	  // "ui-droppable-active": "ui-state-highlight"
					        	},
					        	drop: function( event, ui ) {
					        		ui.draggable.appendTo(this);
					        	}
					        }).appendTo(droppableContainer);
						});

						$('.assign_data_filed_left').append(droppableContainer);
						  
						var sortableDataFields = $('<div class="sortable dropable data_fields"></div>').droppable({
					        	accept: ".draggable",
					        	classes: {
					        	  // "ui-droppable-active": "ui-state-highlight"
					        	},
					        	drop: function( event, ui ) {
					        		ui.draggable.appendTo(this);
					        	}
					        });
						$.each(result.columns, function(key, value){
							$('<div id="'+key+'" class="draggable" data-column="'+key+'">'+key+'</div>').draggable({
						        	cancel: "a.ui-icon", // clicking an icon won't initiate dragging
						        	revert: "invalid", // when not dropped, the item will revert back to its initial position
						        	containment: "document",
						        	helper: "clone",
						        	cursor: "move",
						        	connectToSortable: ".sortable"
						        }).appendTo(sortableDataFields);
						});
							
						$('.assign_data_filed_right').append(sortableDataFields);
						// Display uploaded file
						$('.uploaded_file').html("");
						var table = $('<table class="table table-bordered table-hover table-striped"></table>');
						var thead = $('<tr></tr>');
						var tbody = $("<tbody></tbody>");
						$.each(result.data, function(index, items){
							var rowHead = items.fields[0];
							thead.append('<th>SL</th>');			
							$.each(rowHead, function(row_index, row_item){
								thead.append('<th>'+row_index.replace("_", " ")+'</th>');
							});

							$.each(items.fields, function(i, item){
								var tr = $('<tr></tr>');
									tr.append('<td>'+(i+1)+'</td>');
								$.each(item, function(table_key, table_value){
									tr.append('<td>'+table_value+'</td>');
								});

								tbody.append(tr);		
							});
						});

						table.append(thead);
						table.append(tbody);

						$('.uploaded_file').html(table);
					}else if(result.error) {
						alert(result.error);
					}
				},
				error : function(error) {
					console.log(error);
				}
			});
		}
	</script>
</body>
</html>