<?php

use App\Imports\MapsImport;
use App\Map;
use App\TemporaryMap;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/map', function(){
	$datas = Map::all();
	return view('map', compact('datas'));
});

Route::post('/getMapData', function( Request $request ){

	$data = Map::all();

	echo json_encode( $data );
});

Route::post('/getSingleMap', function( Request $request ){

	$data = Map::find($request->id);

	echo json_encode( $data );
});

Route::get('/getMapData', function( Request $request ){
	$homepage = file_get_contents('http://themestarz.net/html/locations/assets/external/data.php');

	$data = json_decode( $homepage, $assoc_array = false );
	echo "<pre>";
	var_dump( $data );
});


Route::get('export', 'MapController@export')->name('export');
Route::get('importExportView', 'MapController@importExportView');
Route::post('import', 'MapController@import')->name('import');

Route::get('/map/fields/{id}', function(Request $request) {
	$data = Map::find($request->id);
	echo "<pre>";
	var_dump($data->fields);
});

Route::get('import', function() {
	return view('import');
});

Route::post('importData', function( Request $request ){
	if($request->ajax()) {
		if($request->hasFile('files')) {
           $files = $request->file('files');
           $results = [];
           $datas = [];
           foreach ($files as $file) {
           		$extenstion = $file->getClientOriginalExtension();
           		$fileName = rand().'.'.$extenstion;
           		$results[] = $fileName;
           		if($extenstion == 'xlsx' || $extenstion == 'XLSX' || $extenstion == 'XLS' || $extenstion == 'xls'){
           			$import = new MapsImport;
           			$data = Excel::import($import, $file);
           			$datas[] = TemporaryMap::find($import->id);
                $labels = $import->labels;
                $map = Map::all();

                // get the column names for the table
                $columns = Schema::getColumnListing('maps');
                // create array where column names are keys, and values are null
                $columns = array_fill_keys($columns, null);
           		}else {
           			$error = "We support only xlsx or xls (excel file) but upload ".$extenstion.". Please upload a valid file.";
           			return response()->json(['error'=> $error]);
           		}
           		
           }
        }
  		return response()->json([
        'success'   => true,
        'data'      => $datas,
        'labels'    => $labels,
        'columns'   => $columns
      ]);
	}
});
