<?php

namespace App\Imports;

use App\TemporaryMap;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;

class MapsImport implements ToCollection, WithHeadingRow
{
    public $id;
    public $labels = [];
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    // public function model(array $row)
    // {
    //     $keys = array_keys( $row );
    //     $values = array_values( $row );
    //     $fields[] = $row;
    //     $translate = [
    //         'Imp'           => 'Imp',
    //         'Articolo'      => 'Article',
    //         'Marchio'       => 'Brand name',
    //         'Tipo Strada'   => 'Road type',
    //         'Via'           => 'Street',
    //         'Comune'        => 'Common',
    //         'Pr'            => 'Pr',
    //     ];
    //     //echo "<pre>";
    //     //var_dump($row);
    //     // return new Map([
    //     //     'fields' => $translate
    //     // ]);

    //     return [
    //         'keys' => $keys,
    //         'fileds' => $fields
    //     ];
    // }

    public function collection(Collection $rows)
    {
        
        $datas = [];
        foreach ($rows[0] as $key => $value) {
            $this->labels[] = $key;
        }
        
        foreach ($rows as $row) 
        {   
            $datas[] = $row;
        }

        // var_dump($datas);
        $map = new TemporaryMap;

        $map->fields = $datas;
        $map->save();

        $this->id = $map->id;

        // return $map->id;
    }
}
